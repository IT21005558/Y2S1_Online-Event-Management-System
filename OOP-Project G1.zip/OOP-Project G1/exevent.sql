-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2022 at 06:48 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exevent`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `title`, `description`, `created_at`) VALUES
(1, 'Server maintains ', 'Going to Add new features, site will not repond during 14 on this Month', '2022-05-13 18:30:00'),
(2, 'Annuel Meet', 'All the members should join this 25th for our annual meet', '2022-05-25 02:30:00'),
(3, 'Merry X-mas', 'Merry Christmas stay happy and safe', '2022-12-24 03:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `attendee_list`
--

CREATE TABLE `attendee_list` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `attendee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendee_list`
--

INSERT INTO `attendee_list` (`id`, `event_id`, `attendee_id`) VALUES
(1, 1, 4),
(4, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`) VALUES
(1, 'Music', 'We can always assis you to find best Soud for announcing and other entatitment purposes'),
(2, 'Venue', 'We can always assis you to find best Place as you wish'),
(3, 'Food', 'We can always assis you to find best Food items');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `available_tickets` int(11) NOT NULL,
  `event_manager_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `online_event` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `venue` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `name`, `description`, `date`, `time`, `available_tickets`, `event_manager_id`, `status`, `online_event`, `category_id`, `venue`) VALUES
(1, 'SLIIT Convocation Kandy 2022', '2022 IT students Convocation. They are going celebrate  this occasion.', '2022-11-22', '09:00:00', 10, 2, 1, 0, 2, 'Royal Hotel Kandy'),
(2, 'Mr.Sudarsha\'s Birthday. ', 'Mr.Sudarsha\'s 24th birthday. ', '2022-06-16', '16:00:00', 10, 2, 2, 2, 3, 'Ashford Hotel Kandy'),
(3, 'Mr.Perera\'s Wedding', 'Mr.Sanath\'s and Ms.Ruwangi\'s Wedding day.', '2022-05-30', '09:00:00', 50, 2, 1, 4, 2, 'Hotel Pinidiya, Peradeniya'),
(4, 'Mr.Rathnayake\'s Wedding Anniversary', 'Mr.Rathnayake\'s and Mrs.Wijesuriya\'s 10th Wedding Anniversary', '2022-06-10', '20:00:00', 20, 2, 1, 2, 2, 'Queen\'s Hotel Kandy '),
(5, ' Homie`s Get together 2022', 'After long tine they are going to meet each other on this day. Join with them.', '2022-12-24', '17:00:00', 100, 2, 2, 2, 1, 'Kingsbury Hotel Kandy'),
(6, 'Thor\'z EDM Night 2022', 'First time in Sri Lankan music industry. ', '2022-05-25', '17:30:00', 100, 2, 1, 2, 1, 'Pallekale Stadium ');

-- --------------------------------------------------------

--
-- Table structure for table `event_story`
--

CREATE TABLE `event_story` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_story`
--

INSERT INTO `event_story` (`id`, `event_id`, `user_id`, `title`, `description`, `created_at`) VALUES
(1, 1, 4, 'convacation', 'We are very grateful for you help us to celebrate this day. you have organized everything we havent to do any thig.thnak you so much ', '2022-11-22 03:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `event_id`, `user_id`, `description`, `rating`, `created_at`) VALUES
(1, 1, 4, 'De', 5, '2021-09-30 22:52:33'),
(4, 1, 1, 'Very good', 4, '2022-05-07 13:22:08');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'Sudarsha', 'sudarsha@gmail.com', 'Booking a date', 'Hey, I have special Occasion to celebrate with my friends on next Monday (23th) its my Birthday. Can you fix a date on 23,help me to arrange a party', '2022-05-21 22:52:33');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expiry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `join_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `NIC` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `email`, `password`, `mobile`, `address`, `join_date`, `NIC`, `role`) VALUES
(1, 'Ravindu', 'Lakshitha', 'ravindu@gmail.com', 'admin', '0771234567', 'No.10, Kandy', '2022-04-30 22:52:33', '123456789V', 'admin'),
(2, 'Gihan', 'Bandara', 'gihan@gmail.com', 'pass', '0756981356', 'No.11, Peradeniya', '2022-05-03 02:42:33', '123456789V', 'event_manager'),
(4, 'Sudarsha', 'Bandara', 'sudarsha@gmail.com', 'pass', '0715482315', 'No.13, Hanthana', '2022-05-06 21:00:12', '123456789V', 'attendee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendee_list`
--
ALTER TABLE `attendee_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eventId` (`event_id`),
  ADD KEY `attendeeUid` (`attendee_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eventUid` (`event_manager_id`),
  ADD KEY `eventCid` (`category_id`);

--
-- Indexes for table `event_story`
--
ALTER TABLE `event_story`
  ADD PRIMARY KEY (`id`),
  ADD KEY `storyEventUid` (`event_id`),
  ADD KEY `storyUserUid` (`user_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedEventUid` (`event_id`),
  ADD KEY `feedUserUid` (`user_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticketEventUid` (`event_id`),
  ADD KEY `ticketUserUid` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attendee_list`
--
ALTER TABLE `attendee_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `event_story`
--
ALTER TABLE `event_story`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendee_list`
--
ALTER TABLE `attendee_list`
  ADD CONSTRAINT `attendeeUid` FOREIGN KEY (`attendee_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `eventId` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `eventCid` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `eventUid` FOREIGN KEY (`event_manager_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `event_story`
--
ALTER TABLE `event_story`
  ADD CONSTRAINT `storyEventUid` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `storyUserUid` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedEventUid` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedUserUid` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ticketEventUid` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ticketUserUid` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
